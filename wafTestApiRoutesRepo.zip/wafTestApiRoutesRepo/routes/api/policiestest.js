const express = require('express');
const router = express.Router();

// @route /creditinsurance/policymanagement/v1/policiestest    

router.get('/', async function(req,res){
			res.send('this should be blocked - fake policies route');
})

module.exports = router;
