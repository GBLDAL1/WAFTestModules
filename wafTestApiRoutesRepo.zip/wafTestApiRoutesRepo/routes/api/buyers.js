const express = require('express');
const router = express.Router();

// @route /creditinsurance/organisationmanagement/v1/buyers

router.get('/', async(req, res) => {
	res.send('Buyer details route');	
});


module.exports = router;
