const express = require('express');
const router = express.Router();

// @route /creditinsurance/nonpayment/v1/cases

router.get('/', async(req, res) => {
	res.send('Nonpayment cases route');	
});


module.exports = router;
