const express = require('express');
const router = express.Router();

// @route /creditinsurance/covermanagement/v1/decisions

router.get('/', async(req, res) => {
	res.send('Cover decisions route');	
});


module.exports = router;
