const express = require('express');
const router = express.Router();

// @route /authenticate/v1/tokens

router.get('/', async(req, res) => {
	res.send('Authentication route');	
});


module.exports = router;
