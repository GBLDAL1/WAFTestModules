const express = require('express');
const router = express.Router();
let app = express();

// Some sample policy data lookup

var policies = {
	policyId: 12345,
	policyHolder: 'Atradius',
	description: 'Test JSON response'
}

var findPolicyById = function(policyId, callback){
	if(!policies[policyId])
	return callback(new Error(
		'No policy matching '
		+ policyId
	));
}

// @route /creditinsurance/policymanagement/v1/policies    with optional query for policyId

router.get('/', async function(req,res){
	let policyReq = req.query.policyId;
	if (policyReq == '12345'){
		res.json(policies)		
	} else {
		res.send('Policies route');
	}
})

module.exports = router;
