//dependencies
const express = require('express');
const app = express();

//API Server init
app.use(express.json({ extended: false}));
app.use(express.static('./static'))
app.get('/', (req, res) => res.send('Test API Routes Running'));

// API ROUTES HERE

app.use('/authenticate/v1/tokens', require('./routes/api/authenticate'));
app.use('/creditinsurance/policymanagement/v1/policies', require('./routes/api/policies'));
app.use('/creditinsurance/covermanagement/v1/decisions', require('./routes/api/decisions'));
app.use('/creditinsurance/oranisationmanagement/v1/buyers', require('./routes/api/buyers'));
app.use('/creditinsurance/nonpaymentmanagement/v1/cases', require('./routes/api/cases'));
app.use('/creditinsurance/policymanagement/v1/policiestest', require('./routes/api/policiestest'));


// static files
app.use(express.static('/static'));
app.get('/index', (req, res) => 
    res.sendFile('/static/index.html', {root: __dirname}));
app.get('/index/CIBT.exe', (req, res) =>
	res.sendFile('/static/CIBT.exe', {root: __dirname}));

// Default is to listen on 8200 
const PORT = process.env.PORT || 8200;

app.listen(PORT, () => console.log(`API Server listening on port ${PORT}`));

