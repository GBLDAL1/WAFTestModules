
function Popup() {
    alert("This could be Malware, but luckily, it's not!");
}

document.onload(Popup())